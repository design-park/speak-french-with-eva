
import React from 'react';

const WorkSection: React.FC = () => {
  const projects = [
    { id: "music-player", title: "Music Player Redesign", category: "UX/UI Design", image: "https://picsum.photos/seed/music/800/600" },
    { id: "hci-research", title: "HCI Research Portal", category: "Research", image: "https://picsum.photos/seed/hci/800/600" },
    { id: "smart-home", title: "Smart Home Dashboard", category: "Product Design", image: "https://picsum.photos/seed/home/800/600" },
    { id: "edu-platform", title: "Educational Platform", category: "Full Case Study", image: "https://picsum.photos/seed/edu/800/600" }
  ];

  return (
    <section id="works" className="py-24 px-8 md:px-24">
      <header className="mb-16">
        <h2 className="text-5xl font-display mb-4 italic">Selected Works</h2>
        <div className="w-20 h-1 bg-black mb-4"></div>
        <p className="font-handwritten text-2xl text-slate-500">From research to interface ♬</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {projects.map((project, idx) => (
          <a key={idx} href={`#project-${project.id}`} className="group cursor-pointer block">
            <div className="overflow-hidden rounded-[2rem] bg-slate-100 mb-6 aspect-[4/3] shadow-inner relative border-4 border-transparent group-hover:border-white transition-all">
              <img 
                src={project.image} 
                alt={project.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <div className="bg-white px-6 py-2 rounded-full font-medium shadow-xl transform translate-y-4 group-hover:translate-y-0 transition-transform">View Project</div>
              </div>
            </div>
            <p className="text-sm font-semibold tracking-widest text-slate-400 uppercase mb-1">{project.category}</p>
            <h3 className="text-2xl font-serif-fancy group-hover:underline underline-offset-4">{project.title}</h3>
          </a>
        ))}
      </div>
    </section>
  );
};

export default WorkSection;
