
import React from 'react';
import { Music, Coffee, Brain, Heart, GraduationCap, Briefcase, Sparkles, Star } from 'lucide-react';

const AboutSection: React.FC = () => {
  const skills = [
    { name: "Product Strategy", color: "bg-blue-100 text-blue-700" },
    { name: "HCI Research", color: "bg-purple-100 text-purple-700" },
    { name: "Interface Design", color: "bg-rose-100 text-rose-700" },
    { name: "Prototyping", color: "bg-amber-100 text-amber-700" },
    { name: "User Testing", color: "bg-emerald-100 text-emerald-700" },
    { name: "Design Systems", color: "bg-indigo-100 text-indigo-700" },
  ];

  const journey = [
    {
      year: "2023 - Present",
      role: "Senior Product Designer",
      company: "Rhythm AI",
      desc: "Leading design for cognitive focus tools, integrating biometric data into adaptive UIs."
    },
    {
      year: "2021 - 2023",
      role: "UX Researcher",
      company: "Soundscape Labs",
      desc: "Conducted deep-dive research into auditory perception and digital context switching."
    },
    {
      year: "2019 - 2021",
      role: "Product Design Intern",
      company: "Harmonize",
      desc: "Designed mobile interfaces for collaborative music production platforms."
    }
  ];

  return (
    <div className="pb-32 selection:bg-rose-200">
      {/* Intro Header Section (Matching Hero Style) */}
      <section className="px-8 md:px-24 pt-12 pb-24 relative overflow-hidden">
        <div className="max-w-6xl mx-auto flex flex-col items-center md:items-start">
          
          <div className="relative inline-block mb-12">
            {/* Left Ornament */}
            <div className="absolute -left-16 top-0 flex flex-col items-center gap-1 opacity-80 scale-90 md:scale-100 hidden md:flex">
               <div className="relative">
                  <span className="text-3xl filter drop-shadow-sm">🎻</span>
                  <span className="absolute -top-1 -right-2 text-xs">✦</span>
               </div>
               <div className="h-4 w-[1px] bg-slate-400"></div>
               <div className="text-2xl mt-[-8px]">✨</div>
               <div className="h-6 w-[0.5px] bg-slate-300"></div>
            </div>

            <div className="flex flex-col items-start ml-0 md:ml-4">
              <h2 className="font-gabriela text-4xl md:text-5xl text-black leading-none mb-2 ml-4">
                A bit
              </h2>
              <div className="flex justify-end w-full pr-4">
                <h3 className="font-gabriela text-3xl md:text-4xl text-black leading-none">
                  about
                </h3>
              </div>
            </div>

            <div className="mt-[-10px] md:mt-[-20px] relative">
              <h1 className="font-magneto text-[6rem] md:text-[9rem] text-slate-900 drop-shadow-[0_4px_4px_rgba(0,0,0,0.1)] leading-none tracking-tight">
                Jihyun
              </h1>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
            <div className="lg:col-span-7">
               <p className="font-serif-fancy text-3xl md:text-4xl text-slate-800 leading-snug mb-8 italic">
                "I believe design is a <span className="text-rose-500 font-bold">composition</span>—an intricate balance of logic, rhythm, and human emotion."
              </p>
              <div className="space-y-6 text-xl text-slate-600 leading-relaxed max-w-2xl">
                <p>
                  My approach to Product Design is rooted in my fascination with **Human-Computer Interaction (HCI)**. I don't just design screens; I design the spaces where humans and machines meet.
                </p>
                <p>
                  With a background that bridges psychological research and visual aesthetics, I specialize in creating interfaces that feel intuitive and "musically" balanced.
                </p>
              </div>
            </div>
            
            <div className="lg:col-span-5 relative">
               {/* Profile Image with "Sticker" Frame */}
               <div className="relative group">
                  <div className="absolute inset-0 bg-slate-200 rounded-[3rem] rotate-3 transition-transform group-hover:rotate-6"></div>
                  <div className="relative z-10 p-4 bg-white rounded-[3rem] border-4 border-white shadow-2xl overflow-hidden -rotate-2 transition-transform group-hover:rotate-0">
                    <img 
                      src="https://picsum.photos/seed/jihyun/800/1000" 
                      alt="Jihyun" 
                      className="w-full aspect-[4/5] object-cover rounded-[2rem]"
                    />
                  </div>
                  {/* Floating Stickers */}
                  <div className="absolute -top-8 -right-8 z-20 animate-bounce">
                    <div className="bg-yellow-100 p-4 rounded-2xl shadow-lg border-2 border-white rotate-12">
                      <Sparkles className="text-yellow-600" />
                    </div>
                  </div>
                  <div className="absolute -bottom-6 -left-6 z-20">
                    <div className="bg-white px-6 py-2 rounded-full shadow-xl border-2 border-slate-50 font-handwritten text-2xl font-bold -rotate-12">
                      Designer ♭
                    </div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Toolkit / Expertise Section */}
      <section className="px-8 md:px-24 py-24 bg-white/50">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col items-center text-center mb-16">
            <h3 className="font-magneto text-5xl text-slate-900 mb-4">My Toolkit</h3>
            <p className="font-handwritten text-2xl text-slate-400">The instruments I use to create 𝄞</p>
          </div>

          <div className="flex flex-wrap justify-center gap-4">
             {skills.map((skill, idx) => (
               <div 
                 key={idx} 
                 className={`${skill.color} px-8 py-4 rounded-full text-xl font-gabriela shadow-sm border-2 border-white hover:-translate-y-1 transition-transform cursor-default`}
               >
                 {skill.name}
               </div>
             ))}
          </div>
        </div>
      </section>

      {/* Journey Section */}
      <section className="px-8 md:px-24 py-24">
        <div className="max-w-4xl mx-auto">
          <header className="mb-16 flex items-center gap-6">
            <div className="p-4 bg-slate-900 rounded-2xl text-white">
              <Briefcase size={32} />
            </div>
            <h3 className="text-4xl font-display italic">Professional Journey</h3>
          </header>

          <div className="space-y-12 relative before:absolute before:left-[1.65rem] before:top-2 before:bottom-2 before:w-[2px] before:bg-slate-100">
            {journey.map((item, idx) => (
              <div key={idx} className="relative pl-16 group">
                <div className="absolute left-0 top-1 w-14 h-14 bg-white border-2 border-slate-100 rounded-full flex items-center justify-center z-10 group-hover:border-slate-900 transition-colors">
                  <div className="w-3 h-3 bg-slate-300 rounded-full group-hover:bg-slate-900 transition-colors"></div>
                </div>
                <div>
                   <span className="text-sm font-bold text-rose-500 uppercase tracking-[0.2em] mb-2 block">{item.year}</span>
                   <h4 className="text-3xl font-gabriela mb-1">{item.role}</h4>
                   <p className="text-xl font-serif-fancy text-slate-800 mb-4 italic">{item.company}</p>
                   <p className="text-slate-500 max-w-xl leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Off-Duty Section */}
      <section className="px-8 md:px-24 py-24 overflow-hidden">
        <div className="max-w-6xl mx-auto bg-slate-900 rounded-[4rem] p-12 md:p-24 text-white relative">
          <div className="absolute bottom-0 right-0 p-12 opacity-5 pointer-events-none">
             <Star size={400} />
          </div>
          
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div>
              <h3 className="font-magneto text-5xl mb-8">Off Duty</h3>
              <p className="text-xl text-slate-400 leading-relaxed mb-12">
                When I'm not pushing pixels or analyzing heatmaps, you'll probably find me exploring the sensory overlaps between sound and space.
              </p>
              
              <div className="space-y-8">
                <div className="flex items-center gap-6">
                  <div className="w-16 h-16 rounded-2xl bg-slate-800 flex items-center justify-center">
                    <Music className="text-rose-400" />
                  </div>
                  <div>
                    <h5 className="font-bold text-lg">Amateur Cellist</h5>
                    <p className="text-slate-500">Practicing Bach Suites and exploring lo-fi loops.</p>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="w-16 h-16 rounded-2xl bg-slate-800 flex items-center justify-center">
                    <Coffee className="text-amber-400" />
                  </div>
                  <div>
                    <h5 className="font-bold text-lg">Coffee Connoisseur</h5>
                    <p className="text-slate-500">Searching for the perfect floral light roast.</p>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="w-16 h-16 rounded-2xl bg-slate-800 flex items-center justify-center">
                    <Brain className="text-purple-400" />
                  </div>
                  <div>
                    <h5 className="font-bold text-lg">Psychology Nerd</h5>
                    <p className="text-slate-500">Always reading about behavior and cognition.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-col justify-center items-center">
               <div className="text-center p-12 border-4 border-dashed border-slate-800 rounded-[3rem]">
                 <Heart size={64} className="mx-auto mb-6 text-rose-500 fill-rose-500/10" />
                 <h4 className="text-3xl font-gabriela mb-4">Let's create <br/> harmony together.</h4>
                 <p className="text-slate-500 mb-8 max-w-xs mx-auto">I'm always open to new collaborations and coffee chats.</p>
                 <a href="#hero" className="inline-block px-10 py-4 bg-white text-slate-900 rounded-full font-serif-fancy text-xl hover:scale-105 active:scale-95 transition-all shadow-xl">
                   Get in touch
                 </a>
               </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutSection;
