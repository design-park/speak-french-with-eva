
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="py-12 px-8 md:px-24 bg-slate-50 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center text-slate-400">
      <div className="mb-4 md:mb-0">
        <p className="font-handwritten text-xl text-slate-600">© 2024 Jihyun. Handcrafted with care.</p>
      </div>
      <div className="flex gap-8">
        <a href="#" className="hover:text-slate-800 transition-colors">LinkedIn</a>
        <a href="#" className="hover:text-slate-800 transition-colors">Dribbble</a>
        <a href="#" className="hover:text-slate-800 transition-colors">Instagram</a>
      </div>
    </footer>
  );
};

export default Footer;
