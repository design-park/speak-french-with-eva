
import React from 'react';
import { Heart, Music } from 'lucide-react';

interface StickerProps {
  color: string;
  type: 'heart' | 'notes';
}

const Sticker: React.FC<StickerProps> = ({ color, type }) => {
  return (
    <div className={`${color} p-4 rounded-xl border-4 border-white sticker-shadow transform transition-all`}>
      {type === 'heart' ? (
        <div className="relative">
          <Heart size={80} className="text-slate-200 fill-slate-50" />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-3xl font-serif-fancy">𝄞</span>
          </div>
          {/* Mock plaid texture overlay */}
          <div className="absolute inset-0 bg-[linear-gradient(45deg,rgba(0,0,0,0.05)_25%,transparent_25%,transparent_50%,rgba(0,0,0,0.05)_50%,rgba(0,0,0,0.05)_75%,transparent_75%,transparent)] bg-[length:10px_10px] opacity-30"></div>
        </div>
      ) : (
        <div className="w-32 h-16 flex items-center justify-center">
          <Music size={40} className="text-slate-800" />
          <div className="ml-2 w-full h-1 bg-slate-800 rounded-full relative">
            <div className="absolute -top-1 left-0 w-2 h-2 bg-slate-800 rounded-full"></div>
            <div className="absolute -top-1 right-0 w-2 h-2 bg-slate-800 rounded-full"></div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sticker;
