
import React from 'react';
import Sticker from './Sticker';
import { ChevronDown } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative w-full h-screen flex flex-col items-center justify-center overflow-hidden px-4 select-none bg-[#E6F0F0]">
      {/* Background Decorative Stickers */}
      <div className="absolute top-[20%] left-[10%] -rotate-12 hover:rotate-0 transition-transform cursor-grab active:cursor-grabbing hidden md:block">
        <Sticker color="bg-white" type="heart" />
      </div>
      
      <div className="absolute bottom-[20%] right-[12%] rotate-6 hover:rotate-12 transition-transform cursor-grab active:cursor-grabbing hidden md:block">
        <Sticker color="bg-white" type="notes" />
      </div>

      {/* Main Hero Content Block */}
      <div className="relative z-10 flex flex-col items-center">
        
        {/* The Staggered Header Group */}
        <div className="relative inline-block">
          
          {/* Left Side Ornament (Moon, Stars, Bow) */}
          <div className="absolute -left-16 top-0 flex flex-col items-center gap-1 opacity-80 scale-90 md:scale-100">
             <div className="relative">
                <span className="text-3xl filter drop-shadow-sm">🌙</span>
                <span className="absolute -top-1 -right-2 text-xs">✦</span>
                <span className="absolute -bottom-1 -left-2 text-xs">✦</span>
             </div>
             <div className="h-4 w-[1px] bg-slate-400"></div>
             <div className="text-2xl mt-[-8px]">🎀</div>
             <div className="h-6 w-[0.5px] bg-slate-300"></div>
          </div>

          {/* Top Row: Hello! & I am */}
          <div className="flex flex-col items-start ml-4">
            <h2 className="font-gabriela text-5xl md:text-6xl text-black leading-none mb-2 ml-4">
              Hello!
            </h2>
            <div className="flex justify-end w-full pr-4">
              <h3 className="font-gabriela text-4xl md:text-5xl text-black leading-none">
                I am
              </h3>
            </div>
          </div>

          {/* Bottom Row: Jihyun */}
          <div className="mt-[-10px] md:mt-[-20px] relative">
            <h1 className="font-magneto text-[7rem] md:text-[10rem] text-slate-900 drop-shadow-[0_4px_4px_rgba(0,0,0,0.1)] leading-none tracking-tight">
              Jihyun
            </h1>
            {/* Korean Name Tag with cute Gamja Flower font */}
            <span className="absolute -right-12 bottom-4 font-korean-cute text-4xl text-slate-600 font-medium rotate-12 bg-white/40 px-3 py-1 rounded-lg backdrop-blur-[2px] border border-white/20 shadow-sm">
              지현
            </span>
          </div>
        </div>
        
        {/* Description Section */}
        <div className="text-center mt-12 max-w-xl">
          <p className="font-medium text-slate-800 text-xl md:text-2xl mb-4 tracking-tight">
            I am a <span className="text-blue-700 border-b-2 border-blue-100">Product Designer</span> with an <span className="text-blue-700 border-b-2 border-blue-100">HCI</span> background.
          </p>
          <p className="text-slate-500 leading-relaxed max-w-md mx-auto italic text-lg opacity-80">
            I am a reliable partner who adapts to dynamic contexts and makes strategic decisions under constraints.
          </p>
        </div>

        {/* Primary CTA Button */}
        <div className="mt-16">
          <button className="px-16 py-4 rounded-full border-[1.5px] border-black bg-white font-serif-fancy text-3xl text-black shadow-[0_6px_20px_rgba(0,0,0,0.06)] hover:shadow-[0_8px_30px_rgba(0,0,0,0.12)] hover:-translate-y-1 active:translate-y-0 active:scale-95 transition-all">
            Wanna Chat?
          </button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <a 
        href="#works"
        className="absolute bottom-12 left-12 flex flex-col items-center group cursor-pointer no-underline outline-none"
      >
        <div className="bg-white/60 backdrop-blur-sm p-4 rounded-[2rem] border border-white/40 shadow-xl flex items-center gap-4 group-hover:-translate-y-2 transition-transform">
           <span className="font-handwritten text-xl text-slate-700 font-bold">Scroll to see my work</span>
           <div className="bg-slate-900 rounded-full p-1.5">
             <ChevronDown size={20} className="animate-bounce text-white" />
           </div>
        </div>
      </a>
    </section>
  );
};

export default Hero;
