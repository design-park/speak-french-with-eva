
import React from 'react';

interface NavbarProps {
  currentHash: string;
  activeSection: string;
}

const Navbar: React.FC<NavbarProps> = ({ currentHash, activeSection }) => {
  const menuItems = [
    { id: 'works', label: 'Works', href: '#works', symbol: '♪' },
    { id: 'about', label: 'About', href: '#about', symbol: '♫' },
    { id: 'resume', label: 'Resume', href: '#resume', symbol: '♭' },
    { id: 'playlists', label: 'Playlists', href: '#playlists', symbol: '𝄞' },
  ];

  return (
    <nav className="fixed top-0 right-0 p-8 z-50">
      <div className="flex space-x-4 md:space-x-8 font-handwritten text-2xl text-slate-800 items-start">
        {menuItems.map((item) => {
          // Rule for active: 
          // 1. If we are on the specific hash page (About, Resume, Playlists)
          // 2. OR if we are on the Home page context and the section is 'works'
          const isExplicitHash = currentHash === item.href;
          const isHomeWorks = (currentHash === '#hero' || currentHash === '#works' || currentHash === '') && 
                              activeSection === 'works' && item.id === 'works';
          
          const isActive = isExplicitHash || isHomeWorks;

          return (
            <a
              key={item.id}
              href={item.href}
              className="relative flex flex-col items-center group pt-2 px-1"
            >
              {/* Active Pill Background with Shadow */}
              <div className={`absolute top-0 left-1/2 -translate-x-1/2 w-[120%] h-10 bg-white rounded-full shadow-[0_4px_12px_rgba(0,0,0,0.08)] transition-all duration-300 pointer-events-none ${isActive ? 'opacity-100 scale-100' : 'opacity-0 scale-75'}`} />
              
              {/* Label */}
              <span className={`relative z-10 transition-transform duration-300 ${isActive ? 'translate-y-0 text-slate-900 font-bold' : 'translate-y-0 hover:scale-110'}`}>
                {item.label}
              </span>
              
              {/* Distinct Musical Note Symbol */}
              <span className={`mt-2 text-2xl transition-all duration-300 transform 
                ${isActive ? 'opacity-100 translate-y-0 scale-110' : 'opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0'}
              `}>
                {item.symbol}
              </span>
            </a>
          );
        })}
      </div>
      
      {/* Home link as logo if not on home page */}
      {currentHash !== '#hero' && currentHash !== '' && (
        <a href="#hero" className="fixed top-8 left-12 font-display italic text-3xl text-slate-900 hover:scale-110 transition-transform">
          Jihyun
        </a>
      )}
    </nav>
  );
};

export default Navbar;
