
import React from 'react';
import { ArrowLeft, ArrowRight, ExternalLink, Calendar, Users, Wrench, Sparkles } from 'lucide-react';

const ProjectDetail: React.FC = () => {
  return (
    <div className="pb-32">
      {/* Project Navigation / Back Button */}
      <div className="px-8 md:px-24 py-8 flex justify-between items-center">
        <a href="#works" className="flex items-center gap-2 font-handwritten text-xl text-slate-500 hover:text-slate-900 transition-colors group">
          <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          <span>Back to all works</span>
        </a>
        <div className="h-[1px] flex-1 mx-8 bg-slate-100 hidden md:block"></div>
        <div className="flex items-center gap-4">
           <span className="font-serif-fancy italic text-slate-400">Next Project</span>
           <ArrowRight size={18} className="text-slate-300" />
        </div>
      </div>

      {/* Hero Header */}
      <section className="px-8 md:px-24 pt-8 pb-20">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end gap-8 mb-16">
            <div className="max-w-2xl">
              <span className="text-indigo-600 font-bold tracking-[0.2em] uppercase text-xs mb-4 block">Case Study • 2024</span>
              <h1 className="font-gabriela text-6xl md:text-8xl text-slate-900 leading-tight mb-6">
                Redefining the Rhythms of Flow
              </h1>
              <p className="font-serif-fancy text-2xl md:text-3xl text-slate-500 leading-relaxed italic">
                How we bridged the gap between musical intuition and digital interfaces for cognitive focus.
              </p>
            </div>
            <div className="hidden lg:block">
              <div className="relative rotate-6">
                <div className="w-32 h-32 bg-yellow-100 rounded-2xl p-4 flex items-center justify-center sticker-shadow border-4 border-white">
                   <Sparkles size={60} className="text-yellow-500" />
                </div>
              </div>
            </div>
          </div>

          {/* Metadata Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-20">
            <div className="p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100 flex flex-col gap-3">
              <div className="p-2 w-fit bg-white rounded-full shadow-sm text-slate-400"><Calendar size={20}/></div>
              <h4 className="font-bold text-slate-900">Timeline</h4>
              <p className="text-slate-500 text-sm">3 Months (Aug - Oct)</p>
            </div>
            <div className="p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100 flex flex-col gap-3">
              <div className="p-2 w-fit bg-white rounded-full shadow-sm text-slate-400"><Users size={20}/></div>
              <h4 className="font-bold text-slate-900">Role</h4>
              <p className="text-slate-500 text-sm">Lead Product Designer</p>
            </div>
            <div className="p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100 flex flex-col gap-3">
              {/* Fixed: Use Wrench instead of non-existent Tool */}
              <div className="p-2 w-fit bg-white rounded-full shadow-sm text-slate-400"><Wrench size={20}/></div>
              <h4 className="font-bold text-slate-900">Tools</h4>
              <p className="text-slate-500 text-sm">Figma, Blender, Framer</p>
            </div>
            <div className="p-8 bg-slate-900 rounded-[2.5rem] text-white flex flex-col gap-3 shadow-xl">
              <div className="p-2 w-fit bg-slate-800 rounded-full text-slate-400"><ExternalLink size={20}/></div>
              <h4 className="font-bold">Live Link</h4>
              <p className="text-slate-400 text-sm">View Prototype</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content Sections */}
      <section className="px-8 md:px-24">
        <div className="max-w-6xl mx-auto">
          {/* Large Hero Image */}
          <div className="rounded-[4rem] overflow-hidden aspect-[16/9] mb-32 shadow-[0_30px_100px_rgba(0,0,0,0.08)] bg-slate-100">
             <img src="https://picsum.photos/seed/case/1600/900" alt="Project Hero" className="w-full h-full object-cover" />
          </div>

          {/* Section: Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 mb-40">
            <div className="lg:col-span-4">
               <h3 className="font-magneto text-5xl text-slate-900 rotate-[-5deg] inline-block mb-8">Overview</h3>
            </div>
            <div className="lg:col-span-8">
               <div className="space-y-8">
                 <p className="font-gabriela text-3xl text-slate-800 leading-snug">
                   The challenge was to create a music interface that didn't just play tracks, but managed cognitive load.
                 </p>
                 <div className="h-[2px] w-full bg-slate-100"></div>
                 <p className="text-xl text-slate-500 leading-relaxed">
                   Leveraging my background in HCI, I explored how auditory frequencies affect flow states. Many users found traditional players too "active"—requiring constant decisions that broke their focus. Our goal was to design an "invisible" experience that anticipated user needs based on their biometric data and task intensity.
                 </p>
               </div>
            </div>
          </div>

          {/* Section: Discovery & Research (Visual Rich) */}
          <div className="mb-40">
             <div className="bg-slate-50 rounded-[4rem] p-12 md:p-24 relative overflow-hidden">
                <div className="absolute top-[-10%] right-[-5%] text-[30rem] font-magneto text-slate-100 pointer-events-none select-none">HCI</div>
                <div className="relative z-10 max-w-3xl">
                   <h3 className="text-5xl font-display italic mb-12">Insights from the Lab</h3>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                      <div className="space-y-4">
                         <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center font-bold shadow-sm">01</div>
                         <h4 className="text-2xl font-serif-fancy">Decision Fatigue</h4>
                         <p className="text-slate-500">Choosing a playlist takes an average of 4.2 minutes—enough to break the initial focus spark.</p>
                      </div>
                      <div className="space-y-4">
                         <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center font-bold shadow-sm">02</div>
                         <h4 className="text-2xl font-serif-fancy">Tempo Match</h4>
                         <p className="text-slate-500">Focus is maximized when auditory tempo matches heart rate during high-intensity tasks.</p>
                      </div>
                   </div>
                </div>
             </div>
          </div>

          {/* Section: Solution / Design System */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 mb-40">
            <div className="lg:col-span-8 order-2 lg:order-1">
               <div className="grid grid-cols-2 gap-6">
                  <div className="aspect-square bg-slate-100 rounded-[3rem] overflow-hidden border-4 border-white shadow-lg">
                    <img src="https://picsum.photos/seed/ui1/600/600" alt="UI detail" className="w-full h-full object-cover" />
                  </div>
                  <div className="aspect-square bg-slate-100 rounded-[3rem] overflow-hidden border-4 border-white shadow-lg mt-12">
                    <img src="https://picsum.photos/seed/ui2/600/600" alt="UI detail" className="w-full h-full object-cover" />
                  </div>
               </div>
            </div>
            <div className="lg:col-span-4 order-1 lg:order-2 flex flex-col justify-center">
               <h3 className="font-magneto text-5xl text-slate-900 mb-8">The Solution</h3>
               <p className="text-xl text-slate-600 leading-relaxed mb-6 font-gabriela">
                 We developed the "Adaptive Aura"—a UI that shifts colors and complexity based on current focus requirements.
               </p>
               <p className="text-slate-500">
                 By minimizing visual clutter during "Deep Flow" and providing richer information during "Exploration," we reduced interface-induced context switching by 65%.
               </p>
            </div>
          </div>

          {/* Section: Conclusion & Results */}
          <div className="border-y border-slate-100 py-32 flex flex-col items-center text-center">
             <div className="font-handwritten text-4xl text-indigo-500 mb-8 font-bold">"Design is not just what it looks like, but how it sounds."</div>
             <h3 className="text-4xl font-display italic mb-12">The Impact</h3>
             <div className="flex flex-wrap justify-center gap-12">
                <div className="flex flex-col items-center">
                   <span className="text-6xl font-magneto text-slate-900">+45%</span>
                   <span className="text-sm font-bold text-slate-400 uppercase tracking-widest mt-2">Retention Rate</span>
                </div>
                <div className="flex flex-col items-center">
                   <span className="text-6xl font-magneto text-slate-900">12k</span>
                   <span className="text-sm font-bold text-slate-400 uppercase tracking-widest mt-2">Active Users</span>
                </div>
                <div className="flex flex-col items-center">
                   <span className="text-6xl font-magneto text-slate-900">4.9/5</span>
                   <span className="text-sm font-bold text-slate-400 uppercase tracking-widest mt-2">App Store Rating</span>
                </div>
             </div>
          </div>

          {/* Footer Navigation */}
          <div className="mt-32 p-16 bg-slate-900 rounded-[4rem] text-white flex flex-col md:flex-row items-center justify-between gap-8 relative overflow-hidden group">
             <div className="absolute inset-0 bg-indigo-600 scale-x-0 origin-left transition-transform duration-700 group-hover:scale-x-100 opacity-20"></div>
             <div className="relative z-10">
                <h4 className="text-3xl font-gabriela mb-2">Ready to see more?</h4>
                <p className="text-slate-400">Let's look at how I tackled the HCI Research Portal next.</p>
             </div>
             <a href="#project-hci-research" className="relative z-10 px-10 py-4 bg-white text-slate-900 rounded-full font-serif-fancy text-xl hover:scale-105 active:scale-95 transition-all shadow-xl">
                Next Case Study
             </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ProjectDetail;
