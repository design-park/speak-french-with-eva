
import React, { useState } from 'react';
import { PlayCircle, ExternalLink, Disc, Music2, Volume2, SkipForward, SkipBack } from 'lucide-react';

const PlaylistSection: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);

  const playlists = [
    { 
      title: "Late Night Focus", 
      description: "Lo-fi beats and ambient textures for deep design work.",
      count: "42 tracks",
      color: "bg-[#E0E7FF]", // Indigo-100
      accent: "text-indigo-600",
      image: "https://picsum.photos/seed/focus/400/400"
    },
    { 
      title: "Creative Spark", 
      description: "Upbeat indie and city-pop to get the ideas flowing.",
      count: "38 tracks",
      color: "bg-[#FEF3C7]", // Amber-100
      accent: "text-amber-600",
      image: "https://picsum.photos/seed/spark/400/400"
    },
    { 
      title: "HCI Reading List", 
      description: "Classical and minimalist piano for reading papers.",
      count: "25 tracks",
      color: "bg-[#D1FAE5]", // Emerald-100
      accent: "text-emerald-600",
      image: "https://picsum.photos/seed/reading/400/400"
    },
    { 
      title: "Weekend Groove", 
      description: "Nu-disco and funky basslines for the weekend.",
      count: "50 tracks",
      color: "bg-[#FFE4E6]", // Rose-100
      accent: "text-rose-600",
      image: "https://picsum.photos/seed/groove/400/400"
    }
  ];

  return (
    <div className="pb-24">
      {/* Immersive Page Header */}
      <section className="px-8 md:px-24 pt-12 pb-20 relative overflow-hidden">
        {/* Decorative Musical Elements */}
        <div className="absolute top-10 right-[10%] opacity-10 rotate-12 pointer-events-none">
          <Disc size={300} className="animate-[spin_10s_linear_infinite]" />
        </div>
        <div className="absolute bottom-0 left-[5%] opacity-5 pointer-events-none">
          <span className="font-magneto text-[20rem] text-slate-900 leading-none select-none">Notes</span>
        </div>

        <div className="max-w-6xl mx-auto relative z-10">
          <div className="flex flex-col md:flex-row items-end gap-6 mb-8">
            <h1 className="font-magneto text-7xl md:text-9xl text-slate-900 leading-none">Playlists</h1>
            <span className="font-handwritten text-3xl text-slate-400 mb-4 font-bold tracking-widest animate-pulse">
              ON REPEAT 𝄞
            </span>
          </div>
          <p className="font-gabriela text-2xl text-slate-600 max-w-2xl leading-relaxed">
            I believe that every design session deserves its own soundtrack. Here is a curated collection of rhythms that fuel my creative process.
          </p>
        </div>
      </section>

      {/* Featured "Now Playing" Experience */}
      <section className="px-8 md:px-24 mb-24">
        <div className="max-w-6xl mx-auto">
          <div className="bg-slate-900 rounded-[3rem] p-8 md:p-12 text-white flex flex-col lg:flex-row items-center gap-12 shadow-2xl relative overflow-hidden group">
            {/* Background Texture */}
            <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.2)_1px,transparent_1px)] bg-[length:24px_24px]"></div>
            
            {/* Vinyl Record Animation */}
            <div className="relative w-64 h-64 md:w-80 md:h-80 shrink-0">
               <div className={`absolute inset-0 bg-slate-800 rounded-full border-[12px] border-slate-700 shadow-2xl transition-transform duration-[3000ms] ease-in-out ${isPlaying ? 'rotate-[360deg]' : 'rotate-0'}`}>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-24 h-24 rounded-full border border-slate-600 flex items-center justify-center bg-slate-900 overflow-hidden">
                      <img src="https://picsum.photos/seed/vinyl/200/200" alt="Vinyl label" className="w-full h-full object-cover opacity-60" />
                    </div>
                  </div>
                  {/* Grooves */}
                  <div className="absolute inset-[15%] rounded-full border border-slate-700/50"></div>
                  <div className="absolute inset-[25%] rounded-full border border-slate-700/50"></div>
                  <div className="absolute inset-[35%] rounded-full border border-slate-700/50"></div>
               </div>
               {/* Tone Arm */}
               <div className={`absolute -top-4 -right-4 w-12 h-32 bg-slate-300 rounded-full origin-top transition-transform duration-700 ${isPlaying ? 'rotate-[15deg]' : 'rotate-0'}`} style={{ clipPath: 'polygon(40% 0, 60% 0, 60% 80%, 100% 100%, 0 100%, 40% 80%)' }}></div>
            </div>

            <div className="flex-1 space-y-6 relative z-10">
              <div className="flex items-center gap-2 text-indigo-400 font-bold tracking-widest uppercase text-xs">
                <Volume2 size={16} />
                <span>Featured Curation</span>
              </div>
              <h2 className="font-gabriela text-5xl md:text-6xl text-white">The Designer's Lo-Fi</h2>
              <p className="text-slate-400 text-lg max-w-lg">
                The ultimate companion for pixel-pushing and deep prototyping. A blend of chillhop and dusty jazz loops.
              </p>
              
              {/* Fake Player Controls */}
              <div className="flex flex-col gap-6 pt-4">
                <div className="flex items-center gap-8">
                  <SkipBack className="cursor-pointer hover:text-indigo-400 transition-colors" />
                  <button 
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="w-20 h-20 bg-white text-slate-900 rounded-full flex items-center justify-center hover:scale-110 active:scale-95 transition-all shadow-xl"
                  >
                    {isPlaying ? <div className="flex gap-1.5"><div className="w-2 h-6 bg-slate-900 rounded-full"></div><div className="w-2 h-6 bg-slate-900 rounded-full"></div></div> : <PlayCircle size={40} className="ml-1" fill="currentColor" />}
                  </button>
                  <SkipForward className="cursor-pointer hover:text-indigo-400 transition-colors" />
                </div>
                
                {/* Visualizer bars */}
                <div className="flex items-end gap-1 h-8">
                  {[...Array(24)].map((_, i) => (
                    <div 
                      key={i} 
                      className={`w-1.5 bg-indigo-500/40 rounded-full transition-all duration-300 ${isPlaying ? 'animate-bounce' : 'h-2'}`}
                      style={{ 
                        height: isPlaying ? `${Math.random() * 100}%` : '8px',
                        animationDelay: `${i * 0.05}s`,
                        animationDuration: '0.5s'
                      }}
                    ></div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Playlist Grid */}
      <section className="px-8 md:px-24">
        <div className="max-w-6xl mx-auto">
          <header className="mb-12 flex justify-between items-end">
            <div>
              <h3 className="text-4xl font-display italic">Vibe Archives</h3>
              <p className="font-handwritten text-xl text-slate-500 mt-2">Pick your rhythm for today ♫</p>
            </div>
            <div className="hidden md:block">
               <button className="px-6 py-2 border border-slate-200 rounded-full hover:bg-slate-50 transition-all font-medium flex items-center gap-2">
                 Follow on Spotify <ExternalLink size={14} />
               </button>
            </div>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            {playlists.map((playlist, idx) => (
              <div key={idx} className="group relative flex flex-col md:flex-row bg-white rounded-[2.5rem] border-2 border-slate-100 hover:border-slate-900 hover:shadow-2xl transition-all duration-500 overflow-hidden cursor-pointer">
                {/* Playlist Art */}
                <div className="w-full md:w-48 h-48 relative overflow-hidden shrink-0">
                  <img src={playlist.image} alt={playlist.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <PlayCircle size={48} className="text-white fill-white/20" />
                  </div>
                </div>

                {/* Content */}
                <div className="p-8 flex flex-col justify-between flex-1">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <span className={`text-[10px] font-bold uppercase tracking-widest ${playlist.accent} bg-slate-50 px-3 py-1 rounded-full`}>
                        {playlist.count}
                      </span>
                      <Music2 size={18} className="text-slate-200 group-hover:text-slate-400 transition-colors" />
                    </div>
                    <h4 className="text-3xl font-gabriela mb-2 group-hover:text-slate-900 transition-colors">{playlist.title}</h4>
                    <p className="text-slate-500 text-sm leading-relaxed mb-6">{playlist.description}</p>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300 group-hover:text-slate-800 flex items-center gap-1 transition-all">
                      Listen <ExternalLink size={12} />
                    </span>
                    <div className="flex gap-1">
                       <div className={`w-1.5 h-1.5 rounded-full ${playlist.color}`}></div>
                       <div className={`w-1.5 h-1.5 rounded-full ${playlist.color} opacity-60`}></div>
                       <div className={`w-1.5 h-1.5 rounded-full ${playlist.color} opacity-30`}></div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-20 text-center">
            <div className="inline-block p-12 bg-white rounded-[3rem] border-4 border-dashed border-slate-100 relative group overflow-hidden">
               <div className="absolute -top-10 -right-10 text-9xl text-slate-50 font-magneto select-none pointer-events-none group-hover:-translate-x-12 transition-transform duration-1000">♫</div>
               <h4 className="text-2xl font-gabriela mb-4">Want a custom vibe?</h4>
               <p className="text-slate-500 max-w-xs mx-auto mb-8 font-medium">
                 I also create seasonal mixes and collaborative boards. Let's exchange some tunes!
               </p>
               <button className="px-10 py-4 bg-slate-900 text-white rounded-full font-serif-fancy text-xl hover:scale-105 active:scale-95 transition-all shadow-xl">
                 DM me a song
               </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PlaylistSection;
