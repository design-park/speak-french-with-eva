
import React, { useEffect, useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import WorkSection from './components/WorkSection';
import PlaylistSection from './components/PlaylistSection';
import AboutSection from './components/AboutSection';
import ProjectDetail from './components/ProjectDetail';
import Footer from './components/Footer';

const App: React.FC = () => {
  const [currentHash, setCurrentHash] = useState(window.location.hash || '#hero');
  const [activeSection, setActiveSection] = useState('hero');

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash || '#hero';
      setCurrentHash(hash);
      
      // If navigating to a standalone page or project, scroll to top
      if (['#about', '#resume', '#playlists'].includes(hash) || hash.startsWith('#project')) {
        window.scrollTo(0, 0);
      }
    };

    window.addEventListener('hashchange', handleHashChange);

    // Observer for Home page scrolling logic
    const observerOptions = {
      root: null,
      rootMargin: '-30% 0px -30% 0px',
      threshold: 0,
    };

    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);
    
    const isHomeContext = currentHash === '#hero' || currentHash === '#works' || currentHash === '';
    
    if (isHomeContext) {
      const heroEl = document.getElementById('hero');
      const worksEl = document.getElementById('works');
      if (heroEl) observer.observe(heroEl);
      if (worksEl) observer.observe(worksEl);
    }

    return () => {
      window.removeEventListener('hashchange', handleHashChange);
      observer.disconnect();
    };
  }, [currentHash]);

  const isHomePage = currentHash === '#hero' || currentHash === '#works' || currentHash === '';
  const isProjectPage = currentHash.startsWith('#project');

  const renderContent = () => {
    if (isHomePage) {
      return (
        <div className="flex flex-col">
          <div id="hero">
            <Hero />
          </div>
          <div id="works" className="bg-white shadow-[0_-20px_60px_rgba(0,0,0,0.03)] relative z-10 rounded-t-[4rem]">
            <WorkSection />
          </div>
        </div>
      );
    }

    if (isProjectPage) {
      return (
        <div className="pt-32 bg-white min-h-screen rounded-t-[4rem]">
          <ProjectDetail />
        </div>
      );
    }

    switch (currentHash) {
      case '#about':
        return (
          <div className="pt-32 bg-white min-h-screen rounded-t-[4rem]">
            <AboutSection />
          </div>
        );
      case '#resume':
        return (
          <div className="pt-32 bg-white min-h-screen rounded-t-[4rem] flex flex-col items-center justify-center">
            <section className="py-12 px-8 md:px-24 text-center max-w-2xl">
              <h2 className="text-5xl font-display italic mb-12">Curriculum Vitae</h2>
              <div className="bg-slate-50 border-2 border-slate-100 p-12 rounded-[3rem] shadow-xl">
                 <p className="font-handwritten text-3xl text-slate-400 mb-8">Ready to create something amazing? ♭</p>
                 <button className="w-full py-5 bg-black text-white rounded-full font-serif-fancy text-2xl hover:bg-slate-800 transition-all shadow-xl active:scale-95">
                   Download Resume.pdf
                 </button>
              </div>
            </section>
          </div>
        );
      case '#playlists':
        return (
          <div className="pt-32 bg-white min-h-screen rounded-t-[4rem]">
            <PlaylistSection />
          </div>
        );
      default:
        return <Hero />;
    }
  };

  return (
    <div className="min-h-screen selection:bg-teal-200">
      <Navbar currentHash={currentHash} activeSection={activeSection} />
      <main>
        {renderContent()}
        <Footer />
      </main>
    </div>
  );
};

export default App;
